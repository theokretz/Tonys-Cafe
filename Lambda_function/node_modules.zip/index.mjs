import { createRequire } from "module";
const require = createRequire(import.meta.url);

const sgMail = require('@sendgrid/mail');

exports.handler = async (event) => {
    sgMail.setApiKey('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');

    const message = {
        to: 'theokretz2001@gmail.com',
        from: 'absender@example.com',
        subject: 'Betreff der E-Mail',
        text: 'Inhalt der E-Mail',
        // Du kannst auch HTML-Inhalte verwenden
    };

    try {
        await sgMail.send(message);
        return { statusCode: 200, body: JSON.stringify('E-Mail wurde erfolgreich gesendet.') };
    } catch (error) {
        console.error(error);
        if (error.response) {
            console.error(error.response.body)
        }
        return { statusCode: error.code, body: JSON.stringify('Ein Fehler ist aufgetreten.') };
    }
};
